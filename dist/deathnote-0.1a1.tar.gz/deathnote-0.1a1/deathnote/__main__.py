from deathnote import main
main()
